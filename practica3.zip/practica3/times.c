/**
 *
 * Descripcion: Implementation of time measurement functions
 *
 * Fichero: times.c
 * Autor: Carlos Aguirre Maeso
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include "permutations.h"
#include "times.h"
#include "search.h"


short average_search_time(pfunc_search method, 
                          pfunc_key_generator generator, 
                          char order, int N, int n_times, 
                          PTIME_AA ptime)
{
    int *perm = NULL, *table = NULL;
    PDICT dict = NULL;
    clock_t start_t, end_t;
    double total_t;
    int i, max_ob, min_ob, ob, pos;
    long total_ob = 0;

    if(!method || !generator || (order != NOT_SORTED && order != SORTED) || N <= 0 || n_times <= 0 || !ptime){
        return ERR;
    }

    ptime->N = N;
    ptime->n_elems = N * n_times;

    dict = init_dictionary(N, order);
    if(!dict){
        return ERR;
    }

    perm = generate_perm(N);
    if(!perm){
        free_dictionary(dict);
        return ERR;
    }

    if(massive_insertion_dictionary(dict, perm, N) == ERR){
        free_dictionary(dict);
        free(perm);
        return ERR;
    }

    table = (int*)malloc((N*n_times)*sizeof(int));
    if(!table){
        free_dictionary(dict);
        free(perm);
        return ERR;
    }

    generator(table, N*n_times, N);

    max_ob = INT_MIN;
    min_ob = INT_MAX; /*Los inicializamos de manera que cualquier 
                     numero siguiente se convierta en el max/min.*/

    start_t = clock();

    for(i = 0 ; i < ptime->n_elems ; i++){
        ob = search_dictionary(dict, table[i], &pos, method);
        if(ob == ERR){
            free_dictionary(dict);
            free(perm);
            free(table);
            return ERR;
        }
        if(ob < min_ob){
            min_ob = ob;
        }
        if(ob > max_ob){
            max_ob = ob;
        }
        total_ob += ob;
    }

    end_t = clock();

    total_t = (double)(end_t - start_t) / ptime->n_elems;

    ptime->time = total_t;
    ptime->average_ob = (double)(total_ob/ptime->n_elems);
    ptime->min_ob = min_ob;
    ptime->max_ob = max_ob;

    free_dictionary(dict);
    free(perm);
    free(table);
    return OK;
}


short generate_search_times(pfunc_search method, 
                            pfunc_key_generator generator, 
                            int order, char* file, 
                            int num_min, int num_max, 
                            int incr, int n_times)
{
    TIME_AA *time = NULL;
    int i, tam, aux;

    if(!method || !generator || (order != NOT_SORTED && order != SORTED) || !file || n_times <= 0 || num_min <= 0 || num_max <= 0 || num_min > num_max || incr <= 0){
        return ERR;
    }
    aux = (num_max - num_min) / incr + 1;

    time=(TIME_AA*)malloc((aux)*sizeof(TIME_AA));

    if(!time){
        return ERR;
    }

    for(i = 0, tam = num_min ; tam <= num_max ; i++, tam += incr){
        if(average_search_time(method, generator, order, tam, n_times, &time[i]) == ERR){
            free(time);
            return ERR;
        }
    }

    if(save_time_table(file, time, aux) == ERR){
        free(time);
        return ERR;
    }

    free(time);
    return OK;
}



short save_time_table(char* file, PTIME_AA ptime, int n_times)
{
  int i;
  FILE *f = NULL;

  if(!file || !ptime || n_times <= 0){
    return ERR;
  }
  
  f = fopen(file,"w");
  if(f == NULL){
   return ERR;
  }

  for(i=0; i < n_times; i++){
    fprintf(f," %d | %f | %f | %d | %d\n", ptime[i].N, ptime[i].time, 
            ptime[i].average_ob, ptime[i].max_ob, ptime[i].min_ob);
  }

  fclose(f);
  return OK;
}
