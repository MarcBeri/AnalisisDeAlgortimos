/**
 *
 * Descripcion: Header file for time measurement functions 
 *
 * Fichero: times.h
 * Version: 1.1
 *
 */

#ifndef TIMES_H
#define TIMES_H

/* constants */

#ifndef ERR
  #define ERR -1
  #define OK (!(ERR))
#endif

#include "search.h"


typedef struct time_aa {
  int N;          
  int n_elems;   
  double time; 
  double average_ob; 
  int min_ob; 
  int max_ob; 
} TIME_AA, *PTIME_AA;


/* Functions */
short average_search_time(pfunc_search method, pfunc_key_generator generator, char order, int N, int n_times, PTIME_AA ptime);
short generate_search_times(pfunc_search method, pfunc_key_generator generator, int order, char* file, int num_min, int num_max, int incr, int n_times);
short save_time_table(char* file, PTIME_AA time, int n_times);

#endif
