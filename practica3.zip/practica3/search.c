/**
 *
 * Description: Implementation of functions for search
 *
 * File: search.c
 * Author: Carlos Aguirre and Javier Sanz-Cruzado
 * Version: 1.0
 * Date: 14-11-2016
 *
 */

#include "search.h"

#include <stdlib.h>
#include <math.h>

/**
 *  Key generation functions
 *
 *  Description: Receives the number of keys to generate in the n_keys
 *               parameter. The generated keys go from 1 to max. The
 * 				 keys are returned in the keys parameter which must be 
 *				 allocated externally to the function.
 */
  
/**
 *  Function: uniform_key_generator
 *               This function generates all keys from 1 to max in a sequential
 *               manner. If n_keys == max, each key will just be generated once.
 */
void uniform_key_generator(int *keys, int n_keys, int max)
{
  int i;

  for(i = 0; i < n_keys; i++) keys[i] = 1 + (i % max);

  return;
}

/**
 *  Function: potential_key_generator
 *               This function generates keys following an approximately
 *               potential distribution. The smaller values are much more 
 *               likely than the bigger ones. Value 1 has a 50%
 *               probability, value 2 a 17%, value 3 the 9%, etc.
 */
void potential_key_generator(int *keys, int n_keys, int max)
{
  int i;

  for(i = 0; i < n_keys; i++) 
  {
    keys[i] = .5+max/(1 + max*((double)rand()/(RAND_MAX)));
  }

  return;
}

PDICT init_dictionary (int size, char order)
{
  PDICT dict = NULL;

  if(size <= 0 || (order != NOT_SORTED && order != SORTED)){
    return NULL;
  }

  dict = (PDICT)malloc(sizeof(PDICT));
  if(!dict){
    return NULL;
  }

  dict->table = (int*)malloc(size*sizeof(int));
  if(!dict->table){
    free(dict);
    return NULL;
  }

  dict->n_data = 0;
  dict->order = order;
  dict->size = size;

	return dict;
}


void free_dictionary(PDICT pdict)
{
	if(!pdict){
    return;
  }
  else if(!pdict->table){
    free(pdict);
    return;
  }
  else{
    free(pdict->table);
    free(pdict);
    return;
  }
  
}

int insert_dictionary(PDICT pdict, int key)
{
  int aux, i, ob = 0;

	if(key < 0 || !pdict || pdict->size == pdict->n_data){
    return ERR;
  }

  if(pdict->order == SORTED){
    pdict->table[pdict->n_data] = key;
    aux = pdict->table[pdict->n_data];
    i = pdict->n_data - 1;
    while(i >= 0 && pdict->table[i] > key){
      ob++;
      pdict->table[i + 1] = pdict->table[i];
      i--;
    }
    
    pdict->table[i + 1] = aux;
    pdict->n_data++;
  }

  if(pdict->order == NOT_SORTED){
    ob++;
    pdict->table[pdict->n_data] = key;
    pdict->n_data++;
  }
  return ob;
}

/*
A=T[U]; j=U-1;
while (j >= P && T[j]>A);
    T[j+1]=T[j]; j--;
T[j+1]=A;

*/

int massive_insertion_dictionary (PDICT pdict,int *keys, int n_keys)
{
  int i, ob = 0;

	if(!pdict || !keys || n_keys <= 0){
    return ERR;
  }

  for(i = 0 ; i < n_keys ; i++){
    ob += insert_dictionary(pdict, keys[i]);
  }

  return ob;
}

int search_dictionary(PDICT pdict, int key, int *ppos, pfunc_search method)
{
	int ob = 0;
  if(!pdict || key <= 0 || !ppos || !method){
    return ERR;
  }

  ob = method(pdict->table, 0, pdict->n_data - 1, key, ppos);
  if(ob == ERR){
    return ERR;
  }

  return ob;
}


/* Search functions of the Dictionary ADT */
int bin_search(int *table,int F,int L,int key, int *ppos)
{
	int mid = 0, ob = 0;
  if(!table || F < 0 || L < 0 || key <= 0 || L < F || !ppos){
    return ERR;
  }

  while(F <= L){
    mid = (F + L) / 2;
    ob++;
    if(table[mid] == key){
      *ppos = mid;
      return ob;
    }
    else if(key > table[mid]){
      F = mid + 1;
    }
    else{
      L = mid - 1;
    }
  }

  *ppos = NOT_FOUND;
  return ob;

}

int lin_search(int *table,int F,int L,int key, int *ppos)
{
	int i, ob = 0;
  if(!table || F < 0 || L < 0 || key <= 0 || L < F || !ppos){
    return ERR;
  }

  for(i = F ; i <= L ; i++){
    ob++;
    if(table[i] == key){
      *ppos = i;
      return ob;
    }
  }

  *ppos = NOT_FOUND;
  return ob;
}

int lin_auto_search(int *table,int F,int L,int key, int *ppos)
{
	int i = 0, ob = 0, aux;
  if(!table || F < 0 || L < 0 || key <= 0 || L < F || !ppos){
    return ERR;
  }

  for(i = F ; i <= L ; i++){
    ob++;
    if(table[i] == key){
      if(i == F){
        *ppos = i;
        return ob;
      }
      else{
        aux = table[i];
        table[i] = table[i-1];
        table[i-1] = aux;
        *ppos = i;
        return ob;
      }
    }
  }

  *ppos = NOT_FOUND;
  return ob;
}
